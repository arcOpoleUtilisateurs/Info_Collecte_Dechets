/* Configuration */

var Configuration =
{
    "GeometryServiceUrl": "https://geowbs.montpellier3m.fr/arcgis/rest/services/Utilities/Geometry/GeometryServer",
    "MapServiceUrl": "https://geowbs.montpellier3m.fr/arcgis/rest/services/CollecteDechets/Carte/MapServer",
    "LocatorUrl": "https://geowbs.montpellier3m.fr/arcgis/rest/services/CollecteDechets/Localisateur_CollecteDechets/GeocodeServer",
    "AdressesUrl": "https://geowbs.montpellier3m.fr/arcgis/rest/services/CollecteDechets/Carte/MapServer/0"
}
