/**
* Constantes pour configuration
*/
var NB_DECIMAL_LAT_LONG = 2;


/** 
* objet map utilisé par l'API ESRI javascript
*/
var map;

require([
    "esri/config",
    "esri/basemaps",
	"esri/map",
    "application/bootstrapmap",
    "esri/dijit/LocateButton",
    "esri/dijit/HomeButton",
    "esri/dijit/BasemapToggle",
    "esri/dijit/Geocoder",
    "esri/dijit/Scalebar",
    "esri/dijit/Popup",
    "esri/geometry/Extent",
    "esri/symbols/MarkerSymbol",
    "esri/symbols/PictureMarkerSymbol",
    "esri/layers/ArcGISDynamicMapServiceLayer",
    "esri/tasks/GeometryService",
    "dojo/dom-construct",
    "dojo/parser",
	"dojo/domReady!"
], function (
   esriConfig, esriBasemaps, Map, BootstrapMap, LocateButton, HomeButton, BasemapToggle, Geocoder, Scalebar, Popup, Extent, MarkerSymbol, PictureMarkerSymbol, ArcGISDynamicMapServiceLayer, GeometryService, domConstruct, parser
) {
    parser.parse();

    esriConfig.defaults.geometryService = new GeometryService(Configuration.GeometryServiceUrl);

    // Basemaps
    esriBasemaps.osm.title = "Rues";
    esriBasemaps.satellite.title = "Satellite";

    // Map
    map = BootstrapMap.create("map", {
        basemap: "osm",
        extent: new Extent(
            {
                xmin: 384621,
                ymin: 5373911,
                xmax: 478486,
                ymax: 5436896,
                spatialReference: { wkid: 3857 }
            }),
        showAttribution: false,
        scrollWheelZoom: true,
        autoResize: true
    });

    map.on("load", function () {
        map.resize(true);
        $(".esriPopup .titlePane .titleButton.close").before($("#printButton"));
        $('#printButton').on('click', function () {
            printCalendar();
        });
    });

    map.on("click", function (event) {
        doIdentify(event.mapPoint);
    });

    map.infoWindow.markerSymbol = new PictureMarkerSymbol('content/images/house.png', 20, 20);

    map.infoWindow.on("hide", function () {
        map.graphics.clear();
    });

    // Barre d'échelle
    var scalebar = new Scalebar({
        map: map,
        scalebarUnit: "metric"
    });

    // Couche des adresses
    var maskLayer = new ArcGISDynamicMapServiceLayer(Configuration.MapServiceUrl);
    maskLayer.opacity = 0.5;
    maskLayer.setVisibleLayers([2]);
    map.addLayer(maskLayer);

    var dataLayer = new ArcGISDynamicMapServiceLayer(Configuration.MapServiceUrl);
    map.addLayer(dataLayer);

    // Locate user button
    var geoLocate = new LocateButton({
        map: map,
        scale: 2500,
    }, "LocateButton");

    geoLocate.on("locate", function (event) {
        if (event.error != null)
            noResult().show();
        else
            doIdentify(event.graphic.geometry);
    });

    geoLocate.on("load", function () {
        $(".zoomLocateButton").prop("title", "Aller à ma position");
    });

    geoLocate.startup();

    // Home button
    var homeButton = new HomeButton({
        theme: "HomeButton",
        map: map,
        visible: true
    }, "HomeButton");
    homeButton.startup();

    // Basemap toggle
    var toggle = new BasemapToggle({
        map: map,
        basemap: "satellite"
    }, "BasemapToggle");

    toggle.startup();

    // Geocoder
    var geocoder = new Geocoder({
        map: map,
        autoComplete: true,
        highlightLocation: false,
        autoNavigate: false,
        searchDelay: 500,
        //arcgisGeocoder: false,
        arcgisGeocoder: {
            name: "Esri World Geocoder",
            sourceCountry: "FR",
            placeholder: "Saisir une adresse...",
            outFields: "StAddr,City",
            searchExtent: new Extent(
            {
                xmin: 406329,
                ymin: 5373911,
                xmax: 453720,
                ymax: 5436896,
                spatialReference: { wkid: 3857 }
            })
        },
        //geocoders: [{
        //    url: Configuration.LocatorUrl,
        //    name: "Localisateur collecte de dechets",
        //    singleLineFieldName: "Single Line Input",
        //    placeholder: "Saisir une adresse...",
        //    outFields: "Ref_ID"
        //}]
    }, "search");

    geocoder.on("select", function (results) {
        map.infoWindow.hide();

        if (results == null) {
            noResult().show();
            return;
        }

        doQuery(results.result.feature.geometry, formatLocatorAddress(results.result.feature));

        //$.get("{0}/{1}?f=json".format(Configuration.AdressesUrl, results.result.feature.attributes.Ref_ID), function (data) {
        //    var voirie = new esri.Graphic($.parseJSON(data).feature);
        //    voirie.geometry = results.result.feature.geometry;

        //    showInfoWindow(voirie.geometry, voirie);
        //});
    });

    geocoder.startup();

    $('.modal').on('show.bs.modal', centerModals);
    $(window).on('resize', centerModals);
});

function doIdentify(location) {
    require([
      "esri/tasks/locator"
    ], function (Locator) {
        map.infoWindow.hide();
        pleaseWait().show();

        var locator = new Locator("http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer");
        locator.setOutSpatialReference(location.spatialReference);
        locator.locationToAddress(
            location,
            50,
            function (event) {
                doQuery(event.location, formatReverseGeocodeAddress(event.address));
            },
            function (event) {
                pleaseWait().hide();
                noResult().show();
            });
    });
}

// Effectue la tache d'identification
function doQuery(location, address) {
    require([
        "esri/tasks/query",
        "esri/tasks/QueryTask",
        "esri/geometry/Extent",
        "esri/geometry/geometryEngine"
    ],
        function (
            Query,
            QueryTask,
            Extent,
            geometryEngine) {

            var buffer = 50.0; // Meters
            map.infoWindow.hide();
            pleaseWait().show();


            setTimeout(function () {
                var query = new Query();
                query.geometry = new Extent(location.x - buffer, location.y - buffer, location.x + buffer, location.y + buffer, location.spatialReference);
                query.spatialRelationship = Query.SPATIAL_REL_INTERSECTS;
                //query.where = "Join_Count=1";
                query.returnGeometry = true;
                query.outFields = ["*"];

                var queryTask = new QueryTask(Configuration.AdressesUrl);

                queryTask.execute(query, function (featureSet) {
                    pleaseWait().hide();

                    if (featureSet.features.length == 0) {
                        noResult().show();
                        return;
                    }

                    var closestDistance = Number.MAX_VALUE;
                    var closestFeature = null;

                    $.each(featureSet.features, function (index, feature) {
                        var dist = geometryEngine.distance(feature.geometry, location);

                        if (dist < closestDistance) {
                            closestDistance = dist;
                            closestFeature = feature;
                        }
                    });

                    //showInfoWindow(closestFeature.geometry, closestFeature);
                    closestFeature.geometry = location;
                    showInfoWindow(location, closestFeature, address);
                });
            }, 1000);
        });
}

function showInfoWindow(infoWindowLocation, feature, address) {
    map.infoWindow.resize(500, 300);
    map.infoWindow.highlight = true;
    var selInfoTemplate = new esri.InfoTemplate("${Adresse}", $('#infoWindow').html());
    feature.setInfoTemplate(selInfoTemplate);
    //feature.attributes.Adresse = "{0} {1} {2}, {3}".format(feature.attributes.NumeroVoie, feature.attributes.TypeVoie, feature.attributes.NomVoie, feature.attributes.Commune);
    //feature.attributes.Adresse = feature.attributes.AdresseAffichage;
    //feature.attributes.Adresse = feature.attributes.adresseaffichage;
    feature.attributes.Adresse = address;
    feature.symbol = map.infoWindow.markerSymbol;
    map.infoWindow.setFeatures([feature]);
    
    map.setScale(1000).then(function () {
        map.centerAt(infoWindowLocation).then(function () {
            map.graphics.add(feature);
            map.infoWindow.show(infoWindowLocation);
        });

    });

    $('[data-toggle="popover"]').popover();
}

function formatLocatorAddress(feature) {
    return "{0}, {1}".format(feature.attributes.StAddr, feature.attributes.City);
}

function formatReverseGeocodeAddress(address) {
    return "{0}, {1}".format(address.Address, address.City);
}

function printCalendar() {
    $.ajax({
        url: "print.html",
        success: function (data) {
            var thePopup = window.open("", "Member Listing", "height=" + screen.height + ",width=" + screen.width + ",menubar=0,location=0,scrollbars=yes,resizable=yes");
            data = data.replace("$adresse$", $('.esriPopup .esriPopupWrapper .titlePane .title').text());
            data = data.replace("$calendrier$", $('.esriPopup .esriPopupWrapper .contentPane #collectCalendar')[0].outerHTML);
            data = data.replace("$commentaire$", $('.esriPopup .esriPopupWrapper .contentPane #commentaire')[0].outerHTML);
            thePopup.document.write(data);
        },
        async: false
    });
}

String.prototype.format = String.prototype.f = function () {
    var s = this,
        i = arguments.length;

    while (i--) {
        if (arguments[i] == null) {
            arguments[i] = "";
        }
        s = s.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i].toString().replace(/'/g, "&apos;"));
    }
    return s;
};

Number.prototype.formatNumber = function (c, d, t) {
    var n = this,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
        j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};

function pleaseWait() {
    var $pleaseWaitModal = null;

    return {
        show: function () {
            $pleaseWaitModal = $("#modalWait");
            $pleaseWaitModal.modal({
                backdrop: "static",
                keyboard: false
            });
        },

        hide: function () {
            // You could call JQuery's fadeTo() here to accomplish your fade effects
            $("#modalWait.modal.in").modal("hide");
        }
    };
}

function noResult() {
    return {
        show: function () {
            $("#modalNoResult").modal("show");
        },

        hide: function () {
            // You could call JQuery's fadeTo() here to accomplish your fade effects
            $("#modalNoResult.modal.in").modal("hide");
        }
    };
}

/* center modal */
function centerModals() {
    $('.modal').each(function (i) {
        var $clone = $(this).clone().css('display', 'block').appendTo('body');
        var top = Math.round(($clone.height() - $clone.find('.modal-content').height()) / 2);
        top = top > 0 ? top : 0;
        $clone.remove();
        $(this).find('.modal-content').css("margin-top", top);
    });
}
